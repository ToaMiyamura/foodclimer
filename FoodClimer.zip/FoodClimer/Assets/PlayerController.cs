using System.Collections;
using System.Collections.Generic;
using TMPro;
using UnityEngine;

public class PlayerController : MonoBehaviour
{
    public float speed = 5f;//�ړ��X�s�[�h
    public float jump = 30f;//�W�����v��
    Rigidbody rb;
    private bool ground;//�n�ʂɒ��n���������肷��ϐ�

    void Start()
    {
        rb = GetComponent<Rigidbody>();
    }
    void Update()
    {
        if (ground == true)
        {
            //if (Input.GetButtonDown("joystick button 0")) 
            if (Input.GetKeyDown(KeyCode.Space))//�X�y�[�X�L�[�ŃW�����v
            {
                ground = false;
                rb.AddForce(Vector3.up * jump);
            }
        }
    }

    private void OnCollisionEnter(Collision other)//�n�ʂɐG�ꂽ�Ƃ��̏���
    {
        if (other.gameObject.tag == "ground")
        {
            ground = true;
        }
    }
    private void FixedUpdate()
    {
        var hori = Input.GetAxis("Horizontal");
        var vert = Input.GetAxis("Vertical");
        
        rb.velocity=new Vector3(hori,0,vert)*speed;
    }
}
